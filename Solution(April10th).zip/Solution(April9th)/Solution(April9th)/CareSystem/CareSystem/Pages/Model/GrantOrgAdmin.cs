﻿namespace CareSystem.Pages.Model
{
    public class GrantOrgAdmin
    {
        public int AdminID { get; set; }
        public string AdminFirstName { get; set; }
        public string AdminLastName { get; set; }
        public string AdminTitle { get; set; }
    }
}
