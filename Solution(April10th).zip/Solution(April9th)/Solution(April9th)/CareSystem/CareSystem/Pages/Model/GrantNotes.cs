﻿namespace CareSystem.Pages.Model
{
    public class GrantNotes
    {
        public int GrantNotesID { get; set; }
        public int GrantID { get; set; }
        public string GrantContent { get; set; }
    }
}
