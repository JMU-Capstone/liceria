﻿namespace CareSystem.Pages.Model
{
    public class Meeting
    {
        public int MeetingID { get; set; }
        public int AdminID { get; set; }
        public int RepID { get; set; }
        public string MeetingMinutes { get; set; }
    }
}
