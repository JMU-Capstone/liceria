﻿namespace CareSystem.Pages.Model
{
    public class Users
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string UserAddress { get; set; }
        public string City { get; set; }
        public string UserState { get; set; }
        public string UserType { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
