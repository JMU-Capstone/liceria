﻿namespace CareSystem.Pages.Model
{
    public class HashedCredentials
    {
        public int HashedCredentialsID { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
