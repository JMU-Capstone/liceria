﻿namespace CareSystem.Pages.Model
{
    public class PotentialPartner
    {
        public int AdminID { get; set; }
        public int RepID { get; set; }
        public string PotentialStatus { get; set; }
        public string OrgTitle { get; set; }
    }
}
