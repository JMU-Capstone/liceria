﻿namespace CareSystem.Pages.Model
{
    public class Faculty
    {
        public int FacultyID { get; set; }
        public string FacultyFirstName { get; set; }
        public string FacultyLastName { get; set; }
        public string FacultyTitle { get; set; }
    }
}
