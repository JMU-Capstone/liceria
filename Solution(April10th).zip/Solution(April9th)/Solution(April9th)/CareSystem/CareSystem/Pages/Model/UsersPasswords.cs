﻿namespace CareSystem.Pages.Model
{
    public class UsersPasswords
    {
        public int UserID { get; set; }
        public string Username { get; set; }
        public string HashedPassword { get; set; }
    }
}
