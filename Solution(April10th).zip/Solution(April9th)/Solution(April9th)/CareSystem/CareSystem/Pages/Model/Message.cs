﻿namespace CareSystem.Pages.Model
{
    public class Message
    {
        public int MessageID { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public int SenderID { get; set; }
        public int ReceiverID { get; set; }
        public Users Sender { get; set; }

    }
}
