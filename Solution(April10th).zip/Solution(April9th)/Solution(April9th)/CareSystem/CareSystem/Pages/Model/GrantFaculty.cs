﻿namespace CareSystem.Pages.Model
{
    public class GrantFaculty
    {
        public int GrantID { get; set; }
        public int FacultyID { get; set; }
    }
}
