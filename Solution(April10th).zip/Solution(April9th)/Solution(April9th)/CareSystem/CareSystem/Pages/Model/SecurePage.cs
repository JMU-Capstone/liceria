﻿using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Mvc.Filters;

using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CareSystem.Page
{
    public class SecurePageModel : PageModel

    {
        public override void OnPageHandlerExecuting(PageHandlerExecutingContext context)
        {
            // Check for a session variable (e.g., "username") 

            if (string.IsNullOrEmpty(HttpContext.Session.GetString("username")))

            {

                // Redirect to the login page if the user isn't logged in 

                context.Result = RedirectToPage("/Landing/DBLogin");

            }

            base.OnPageHandlerExecuting(context);

        }

    }

}
