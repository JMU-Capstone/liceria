﻿namespace CareSystem.Pages.Model
{
    public class Grants
    {
        public int GrantID { get; set; }
        public int? RepID { get; set; }
        public string GrantTitle { get; set; }
        public string Category { get; set; }
        public string FundingOrg { get; set; }
        public DateTime SubmitDate { get; set; } = DateTime.Now;
        public DateTime? AwardDate { get; set; }
        public decimal AwardAmount { get; set; }
        public string ProjectLead { get; set; }
        public string GrantStatus { get; set; }
    }
}
