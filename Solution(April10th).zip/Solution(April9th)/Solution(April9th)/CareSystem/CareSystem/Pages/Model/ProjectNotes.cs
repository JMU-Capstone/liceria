﻿namespace CareSystem.Pages.Model
{
    public class ProjectNotes
    {
        public int ProjectNotesID { get; set; }
        public int ProjectID { get; set; }
        public string Contents { get; set; }

    }
}
