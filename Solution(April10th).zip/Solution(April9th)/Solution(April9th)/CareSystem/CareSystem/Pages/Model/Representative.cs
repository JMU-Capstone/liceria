﻿namespace CareSystem.Pages.Model
{
    public class Representative
    {
        public int RepID { get; set; }
        public string RepFirstName { get; set; }
        public string RepLastName { get; set; }
        public string RepStatus { get; set; }
        public string Contact { get; set; }
        public string OrgType { get; set; }
    }
}
