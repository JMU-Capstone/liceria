﻿namespace CareSystem.Pages.Model
{
    public class ProjectGrant
    {
        public int ProjectID { get; set; }
        public int AdminID { get; set; }
        public int RepID { get; set; }
        public string ProjectTitle { get; set; }
        public DateTime DueDate { get; set; }
        public string ProjectStatus { get; set; }

    }
}
