﻿namespace CareSystem.Pages.Model
{
    public class NonFaculty
    {
        public int NonFacultyID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Department { get; set; }
        public string NonFacultyTitle { get; set; }

    }
}