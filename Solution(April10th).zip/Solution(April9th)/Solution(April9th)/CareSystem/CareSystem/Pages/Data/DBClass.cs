﻿using System.Data;
using System.Data.SqlClient;
using CareSystem.Pages.Model;
using Microsoft.Identity.Client;
using Microsoft.AspNetCore.Identity;


namespace CareSystem.Pages.Data
{
    public class DBClass
    {
        public static SqlConnection CareSystemDBConnection = new SqlConnection();
        public static SqlConnection AUTHDBConnection = new SqlConnection();

        private static readonly String? CareSystemDBConnString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
        private static readonly String? AuthConnString = "Server=Localhost;Database=AUTH;Trusted_Connection=True";

        //Class Connection Initiation
        public static SqlDataReader UsersReader()
        {
            SqlCommand cmdUsersRead = new SqlCommand();
            cmdUsersRead.Connection = CareSystemDBConnection;
            cmdUsersRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdUsersRead.CommandText = "SELECT * FROM Users";
            cmdUsersRead.Connection.Open();

            SqlDataReader tempReader = cmdUsersRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader GrantOrgAdminReader()
        {
            SqlCommand cmdGrantOrgAdminRead = new SqlCommand();
            cmdGrantOrgAdminRead.Connection = CareSystemDBConnection;
            cmdGrantOrgAdminRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdGrantOrgAdminRead.CommandText = "SELECT * FROM GrantOrgAdmin";
            cmdGrantOrgAdminRead.Connection.Open();

            SqlDataReader tempReader = cmdGrantOrgAdminRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader NonFacultyReader()
        {
            SqlCommand cmdNonFacultyRead = new SqlCommand();
            cmdNonFacultyRead.Connection = CareSystemDBConnection;
            cmdNonFacultyRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdNonFacultyRead.CommandText = "SELECT * FROM Administrator";
            cmdNonFacultyRead.Connection.Open();

            SqlDataReader tempReader = cmdNonFacultyRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader FacultyReader()
        {
            SqlCommand cmdFacultyRead = new SqlCommand();
            cmdFacultyRead.Connection = CareSystemDBConnection;
            cmdFacultyRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdFacultyRead.CommandText = "SELECT * FROM Faculty";
            cmdFacultyRead.Connection.Open();

            SqlDataReader tempReader = cmdFacultyRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader RepresentativeReader()
        {
            SqlCommand cmdRepresentativeRead = new SqlCommand();
            cmdRepresentativeRead.Connection = CareSystemDBConnection;
            cmdRepresentativeRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdRepresentativeRead.CommandText = "SELECT * FROM Representative";
            cmdRepresentativeRead.Connection.Open();

            SqlDataReader tempReader = cmdRepresentativeRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader ProjectGrantReader()
        {
            SqlCommand cmdProjectGrantRead = new SqlCommand();
            cmdProjectGrantRead.Connection = CareSystemDBConnection;
            cmdProjectGrantRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdProjectGrantRead.CommandText = "SELECT * FROM ProjectGrant";
            cmdProjectGrantRead.Connection.Open();

            SqlDataReader tempReader = cmdProjectGrantRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader GrantsReader()
        {
            SqlCommand cmdGrantsRead = new SqlCommand();
            cmdGrantsRead.Connection = CareSystemDBConnection;
            cmdGrantsRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdGrantsRead.CommandText = "SELECT * FROM Grants";
            cmdGrantsRead.Connection.Open();

            SqlDataReader tempReader = cmdGrantsRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader GrantFacultyReader()
        {
            SqlCommand cmdGrantFacultyRead = new SqlCommand();
            cmdGrantFacultyRead.Connection = CareSystemDBConnection;
            cmdGrantFacultyRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdGrantFacultyRead.CommandText = "SELECT * FROM GrantFaculty";
            cmdGrantFacultyRead.Connection.Open();

            SqlDataReader tempReader = cmdGrantFacultyRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader GrantNotesReader()
        {
            SqlCommand cmdGrantNotesRead = new SqlCommand();
            cmdGrantNotesRead.Connection = CareSystemDBConnection;
            cmdGrantNotesRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdGrantNotesRead.CommandText = "SELECT * FROM Project";
            cmdGrantNotesRead.Connection.Open();

            SqlDataReader tempReader = cmdGrantNotesRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader ProjectNotesReader()
        {
            SqlCommand cmdProjectNotesRead = new SqlCommand();
            cmdProjectNotesRead.Connection = CareSystemDBConnection;
            cmdProjectNotesRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdProjectNotesRead.CommandText = "SELECT * FROM Project";
            cmdProjectNotesRead.Connection.Open();

            SqlDataReader tempReader = cmdProjectNotesRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader PotentialPartner()
        {
            SqlCommand cmdPotentialPartnerRead = new SqlCommand();
            cmdPotentialPartnerRead.Connection = CareSystemDBConnection;
            cmdPotentialPartnerRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdPotentialPartnerRead.CommandText = "SELECT * FROM Project";
            cmdPotentialPartnerRead.Connection.Open();

            SqlDataReader tempReader = cmdPotentialPartnerRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader MeetingReader()
        {
            SqlCommand cmdMeetingRead = new SqlCommand();
            cmdMeetingRead.Connection = CareSystemDBConnection;
            cmdMeetingRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdMeetingRead.CommandText = "SELECT * FROM Project";
            cmdMeetingRead.Connection.Open();

            SqlDataReader tempReader = cmdMeetingRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader MessageReader()
        {
            SqlCommand cmdMessageRead = new SqlCommand();
            cmdMessageRead.Connection = CareSystemDBConnection;
            cmdMessageRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdMessageRead.CommandText = "SELECT * FROM Message";
            cmdMessageRead.Connection.Open();

            SqlDataReader tempReader = cmdMessageRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader Credentials()
        {
            SqlCommand cmdCredentialsRead = new SqlCommand();
            cmdCredentialsRead.Connection = AUTHDBConnection;
            cmdCredentialsRead.Connection.ConnectionString = AuthConnString;
            cmdCredentialsRead.CommandText = "SELECT * FROM Credentials";
            cmdCredentialsRead.Connection.Open();

            SqlDataReader tempReader = cmdCredentialsRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader UserPasswords()
        {
            SqlCommand cmdUserPasswordsRead = new SqlCommand();
            cmdUserPasswordsRead.Connection = AUTHDBConnection;
            cmdUserPasswordsRead.Connection.ConnectionString = AuthConnString;
            cmdUserPasswordsRead.CommandText = "SELECT * FROM UserPasswords";
            cmdUserPasswordsRead.Connection.Open();

            SqlDataReader tempReader = cmdUserPasswordsRead.ExecuteReader();
            return tempReader;
        }


        //Home Page Connections
        public static SqlDataReader GeneralGrantQuery(string sqlQuery)
        {
            SqlConnection connection = new SqlConnection(CareSystemDBConnString);
            SqlCommand cmdGeneralRead = new SqlCommand(sqlQuery, connection);
            connection.Open();
            return cmdGeneralRead.ExecuteReader(CommandBehavior.CloseConnection);
        }

        public static SqlDataReader GeneralProjectQuery(string sqlQuery)
        {
            SqlConnection connection = new SqlConnection(CareSystemDBConnString);
            SqlCommand cmdGeneralProjectRead = new SqlCommand(sqlQuery, connection);
            connection.Open();
            return cmdGeneralProjectRead.ExecuteReader(CommandBehavior.CloseConnection);
        }

        public static void InsertGrantQuery(string sqlQuery, SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(CareSystemDBConnString))
            {
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        public static void InsertProjectQuery(string sqlQuery, SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(CareSystemDBConnString))
            {
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        //Grant Kickoff Page Connections
        public static SqlDataReader SingleGrantReader(int GrantID)
        {
            SqlCommand cmdGrantRead = new SqlCommand();
            cmdGrantRead.Connection = CareSystemDBConnection;
            cmdGrantRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdGrantRead.CommandText = "SELECT * FROM Grants WHERE GrantID = " + GrantID;
            cmdGrantRead.Connection.Open();

            SqlDataReader tempReader = cmdGrantRead.ExecuteReader();
            return tempReader;
        }

        public static void InsertGrant(Grants g)
        {
            string sqlQuery = "INSERT INTO Grants (FacultyID, Category, FundingOrg, SubmitDate, AwardDate, AwardAmount) VALUES (";
            sqlQuery += g.RepID + ",'";
            sqlQuery += g.Category + "','";
            sqlQuery += g.FundingOrg + "','";
            sqlQuery += g.SubmitDate.ToString("yyyy-MM-dd HH:mm:ss") + "','";
            sqlQuery += g.AwardDate?.ToString("yyyy-MM-dd HH:mm:ss") + "',";
            sqlQuery += g.AwardAmount + ")";

            SqlCommand cmdGrantInsert = new SqlCommand();
            cmdGrantInsert.Connection = CareSystemDBConnection;
            cmdGrantInsert.Connection.ConnectionString = CareSystemDBConnString;
            cmdGrantInsert.CommandText = sqlQuery;
            cmdGrantInsert.Connection.Open();

            cmdGrantInsert.ExecuteNonQuery();
            cmdGrantInsert.Connection.Close();
        }

        public static void UpdateGrant(Grants g)
        {
            string sqlQuery = "UPDATE Grants SET ";
            sqlQuery += "FacultyID = " + g.RepID + ",";
            sqlQuery += "Category = '" + g.Category + "',";
            sqlQuery += "FundingOrg = '" + g.FundingOrg + "',";
            sqlQuery += "SubmitDate = '" + g.SubmitDate.ToString("yyyy-MM-dd HH:mm:ss") + "',";
            sqlQuery += "AwardDate = '" + g.AwardDate?.ToString("yyyy-MM-dd HH:mm:ss") + "',";
            sqlQuery += "AwardAmount = " + g.AwardAmount;
            sqlQuery += " WHERE GrantID = " + g.GrantID;

            SqlCommand cmdGrantUpdate = new SqlCommand();
            cmdGrantUpdate.Connection = CareSystemDBConnection;
            cmdGrantUpdate.Connection.ConnectionString = CareSystemDBConnString;
            cmdGrantUpdate.CommandText = sqlQuery;
            cmdGrantUpdate.Connection.Open();

            cmdGrantUpdate.ExecuteNonQuery();
            cmdGrantUpdate.Connection.Close();
        }

        public static List<Faculty> GetAllFaculty()
        {
            List<Faculty> facultyList = new List<Faculty>();
            string sqlQuery = "SELECT * FROM Faculty";

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = CareSystemDBConnection;
            cmd.Connection.ConnectionString = CareSystemDBConnString;
            cmd.CommandText = sqlQuery;
            cmd.Connection.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Faculty f = new Faculty();
                f.FacultyID = (int)reader["FacultyID"];
                f.FacultyFirstName = reader["FacultyFirstName"].ToString();
                f.FacultyLastName = reader["FacultyLastName"].ToString();
                facultyList.Add(f);
            }
            reader.Close();
            cmd.Connection.Close();

            return facultyList;
        }

        //Project Kickoff Page Connections
        public static SqlDataReader SingleProjectReader(int ProjectID)
        {
            SqlCommand cmdProjectRead = new SqlCommand();
            cmdProjectRead.Connection = CareSystemDBConnection;
            cmdProjectRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdProjectRead.CommandText = "SELECT * FROM ProjectGrant WHERE ProjectID = " + ProjectID;
            cmdProjectRead.Connection.Open();

            SqlDataReader tempReader = cmdProjectRead.ExecuteReader();
            return tempReader;
        }

        public static void InsertProjectGrant(ProjectGrant pg)
        {
            string sqlQuery = "INSERT INTO ProjectGrant (AdminID, RepID, ProjectTitle, DueDate, ProjectStatus) VALUES (";
            sqlQuery += pg.AdminID + ",";
            sqlQuery += pg.RepID + ",'";
            sqlQuery += pg.ProjectTitle + "', '";
            sqlQuery += pg.DueDate.ToString("yyyy-MM-dd HH:mm:ss") + "', '";
            sqlQuery += pg.ProjectStatus + "')";

            SqlCommand cmdProjectInsert = new SqlCommand();
            cmdProjectInsert.Connection = CareSystemDBConnection;
            cmdProjectInsert.Connection.ConnectionString = CareSystemDBConnString;
            cmdProjectInsert.CommandText = sqlQuery;
            cmdProjectInsert.Connection.Open();

            cmdProjectInsert.ExecuteNonQuery();
            cmdProjectInsert.Connection.Close();
        }

        public static void UpdateProject(ProjectGrant pg)
        {
            string sqlQuery = "UPDATE ProjectGrant SET ";
            sqlQuery += "AdminID = " + pg.AdminID + ",";
            sqlQuery += "RepID = '" + pg.RepID + ",'";
            sqlQuery += "ProjectTitle = '" + pg.ProjectTitle + "',";
            sqlQuery += "DueDate = '" + pg.DueDate.ToString("yyyy-MM-dd HH:mm:ss") + "',";
            sqlQuery += "ProjectStatus = " + pg.ProjectStatus;
            sqlQuery += " WHERE ProjectID = " + pg.ProjectID;

            SqlCommand cmdProjectUpdate = new SqlCommand();
            cmdProjectUpdate.Connection = CareSystemDBConnection;
            cmdProjectUpdate.Connection.ConnectionString = CareSystemDBConnString;
            cmdProjectUpdate.CommandText = sqlQuery;
            cmdProjectUpdate.Connection.Open();

            cmdProjectUpdate.ExecuteNonQuery();
        }

        public static List<GrantOrgAdmin> GetAllAdmin()
        {
            List<GrantOrgAdmin> adminList = new List<GrantOrgAdmin>();
            string sqlQuery = "SELECT * FROM GrantOrgAdmin";

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = CareSystemDBConnection;
            cmd.Connection.ConnectionString = CareSystemDBConnString;
            cmd.CommandText = sqlQuery;
            cmd.Connection.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                GrantOrgAdmin a = new GrantOrgAdmin();
                a.AdminID = (int)reader["AdminID"];
                a.AdminFirstName = reader["AdminFirstName"].ToString();
                a.AdminLastName = reader["AdminLastName"].ToString();
                a.AdminTitle = reader["AdminTitle"].ToString();
                adminList.Add(a);
            }
            reader.Close();
            cmd.Connection.Close();

            return adminList;
        }

        //Registration Page Connections

        public static SqlDataReader GeneralAdminQuery(string sqlQuery)
        {
            SqlConnection connection = new SqlConnection(CareSystemDBConnString);
            SqlCommand cmdGeneralAdmin = new SqlCommand(sqlQuery, connection);
            connection.Open();
            return cmdGeneralAdmin.ExecuteReader(CommandBehavior.CloseConnection);
        }

        public static SqlDataReader GeneralRepresentativeQuery(string sqlQuery)
        {
            SqlConnection connection = new SqlConnection(CareSystemDBConnString);
            SqlCommand cmdGeneralRepresentative = new SqlCommand(sqlQuery, connection);
            connection.Open();
            return cmdGeneralRepresentative.ExecuteReader(CommandBehavior.CloseConnection);
        }

        public static SqlDataReader GeneralFacultyQuery(string sqlQuery)
        {
            SqlConnection connection = new SqlConnection(CareSystemDBConnString);
            SqlCommand cmdGeneralFaculty = new SqlCommand(sqlQuery, connection);
            connection.Open();
            return cmdGeneralFaculty.ExecuteReader(CommandBehavior.CloseConnection);
        }

        public static SqlDataReader GeneralNonFacultyQuery(string sqlQuery)
        {
            SqlConnection connection = new SqlConnection(CareSystemDBConnString);
            SqlCommand cmdGeneralNonFaculty = new SqlCommand(sqlQuery, connection);
            connection.Open();
            return cmdGeneralNonFaculty.ExecuteReader(CommandBehavior.CloseConnection);
        }

        //Message Page Connections

        public static SqlDataReader GetMessagesForUser(int userId)
        {
            if (string.IsNullOrEmpty(CareSystemDBConnection.ConnectionString))
            {
                CareSystemDBConnection.ConnectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            }

            if (CareSystemDBConnection.State == ConnectionState.Closed)
            {
                CareSystemDBConnection.Open();
            }

            string query = @"SELECT 
                    m.MessageID, 
                    m.Subject, 
                    m.Body, 
                    m.SenderID, 
                    u.UserName AS SenderName 
                 FROM Message m 
                 INNER JOIN Users u ON m.SenderID = u.UserID 
                 WHERE m.ReceiverID = @UserID";

            SqlCommand cmd = new SqlCommand(query, CareSystemDBConnection);
            cmd.Parameters.AddWithValue("@UserID", userId);

            return cmd.ExecuteReader();
        }

        public static void SendMessage(int senderId, int receiverId, string subject, string body)
        {
            try
            {
                if (CareSystemDBConnection.State != ConnectionState.Open)
                    CareSystemDBConnection.Open();

                string query = @"INSERT INTO Message (Subject, Body, SenderID, ReceiverID)
                                 VALUES (@Subject, @Body, @SenderID, @ReceiverID)";

                SqlCommand cmd = new SqlCommand(query, CareSystemDBConnection);
                cmd.Parameters.AddWithValue("@Subject", subject);
                cmd.Parameters.AddWithValue("@Body", body);
                cmd.Parameters.AddWithValue("@SenderID", senderId);
                cmd.Parameters.AddWithValue("@ReceiverID", receiverId);

                cmd.ExecuteNonQuery();
            }
            finally
            {
                if (CareSystemDBConnection.State == ConnectionState.Open)
                    CareSystemDBConnection.Close();
            }
        }

        //Login Page Connections

        public static int LoginQuery(string loginQuery)
        {
            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = CareSystemDBConnection;
            cmdLogin.Connection.ConnectionString = CareSystemDBConnString;
            cmdLogin.CommandText = loginQuery;
            cmdLogin.Connection.Open();

            int rowCount = (int)cmdLogin.ExecuteScalar();

            return rowCount;
        }



        public static int SecureLogin(string Username, string Password)
        {
            string loginQuery =
                "SELECT COUNT(*) FROM Credentials where Username = @Username and Password = @Password";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = CareSystemDBConnection;
            cmdLogin.Connection.ConnectionString = CareSystemDBConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", Password);

            cmdLogin.Connection.Open();

            int rowCount = (int)cmdLogin.ExecuteScalar();

            return rowCount;
        }

        public static bool HashedParameterLogin(string Username, string Password)
        {
            string loginQuery =
                "SELECT Password FROM HashedCredentials WHERE Username = @Username";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = CareSystemDBConnection;
            cmdLogin.Connection.ConnectionString = CareSystemDBConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);

            cmdLogin.Connection.Open();

            SqlDataReader hashReader = cmdLogin.ExecuteReader();
            if (hashReader.Read())
            {
                string correctHash = hashReader["Password"].ToString();

                if (PasswordHash.ValidatePassword(Password, correctHash))
                {
                    return true;
                }
            }

            return false;
        }

        //Create New User

        public static void CreateHashedUser(string Username, string Password)
        {
            string loginQuery =
                "INSERT INTO HashedCredentials (Username,Password) values (@Username, @Password)";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = CareSystemDBConnection;
            cmdLogin.Connection.ConnectionString = CareSystemDBConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", PasswordHash.HashPassword(Password));

            cmdLogin.Connection.Open();

            cmdLogin.ExecuteNonQuery();

        }

        public static SqlDataReader UserNameReader()
        {
            SqlCommand cmdUsersRead = new SqlCommand();
            cmdUsersRead.Connection = CareSystemDBConnection;
            cmdUsersRead.Connection.ConnectionString = CareSystemDBConnString;
            cmdUsersRead.CommandText = "SELECT * FROM Users";
            cmdUsersRead.Connection.Open();

            SqlDataReader tempReader = cmdUsersRead.ExecuteReader();
            return tempReader;
        }

        public static SqlDataReader GetAllUsers()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = CareSystemDBConnection;
            cmd.Connection.ConnectionString = CareSystemDBConnString;

            cmd.CommandText = @"
                SELECT CAST(AdminID AS INT) AS UserID, (AdminFirstName + ' ' + AdminLastName) AS FullName 
                FROM GrantOrgAdmin
                UNION
                SELECT CAST(NonFacultyID AS INT) AS UserID, (FirstName + ' ' + LastName) AS FullName 
                FROM NonFaculty
                UNION
                SELECT CAST(FacultyID AS INT) AS UserID, (FacultyFirstName + ' ' + FacultyLastName) AS FullName 
                FROM Faculty
                UNION
                SELECT CAST(RepID AS INT) AS UserID, (RepFirstName + ' ' + RepLastName) AS FullName 
                FROM Representative
            ";

            cmd.Connection.Open();
            return cmd.ExecuteReader();
        }

    }
}