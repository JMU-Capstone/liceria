using CareSystem.Pages.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace CareSystem.Pages.Landing
{
    public class DBLoginModel : PageModel
    {
        [BindProperty]
        public string Username { get; set; }
        [BindProperty]
        public string Password { get; set; }
        [BindProperty]
        public string UserType { get; set; }

        public IActionResult OnGet(string logout)
        {
            if (logout == "true")
            {
                HttpContext.Session.Clear();
                ViewData["LoginMessage"] = "Successfully Logged Out!";
            }

            return Page();
        }

        public IActionResult OnPost()
        {

            string loginQuery = "SELECT COUNT(*) FROM Credentials where Username = '"
                                + Username + "' and Password='" + Password + "'";

            if (DBClass.LoginQuery(loginQuery) > 0)
            {
                string role = "";
                switch (Username.ToLower())
                {
                    case "nonfaculty":
                        role = "NonFaculty";
                        break;
                    case "faculty":
                        role = "Faculty";
                        break;
                    case "admin":
                        role = "GrantOrgAdmin";
                        break;
                    case "representative":
                    case "ezelljd":
                        role = "Representative";
                        break;
                    default:
                        role = UserType;
                        break;
                }

                HttpContext.Session.SetString("username", Username);
                HttpContext.Session.SetString("UserType", role);
                DBClass.CareSystemDBConnection.Close();

                switch (role)
                {
                    case "Faculty":
                        return RedirectToPage("/Landing/FacultyLanding");
                    case "NonFaculty":

                        return RedirectToPage("/Landing/NonFaculty");
                    case "GrantOrgAdmin":
                        return RedirectToPage("/Tasks/Home");
                    case "Representative":
                        return RedirectToPage("/Landing/RepLanding");
                    default:
                        return RedirectToPage("Index");
                }
            }
            else
            {
                HttpContext.Session.SetString("LoginError", "Username and/or Password Incorrect");
                DBClass.CareSystemDBConnection.Close();
                return Page();
            }
        }

        public IActionResult OnPostLogoutHandler()
        {
            HttpContext.Session.Clear();
            return Page();
        }
    }
}

