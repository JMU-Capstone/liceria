using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Linq;
using System.Collections.Generic;

namespace CareSystem.Pages.Landing
{
    public class RepLandingModel : PageModel
    {
        public List<RepresentativeData> RepresentativeList { get; set; }

        public IActionResult OnGet()
        {
            string role = HttpContext.Session.GetString("UserType");
            if (role != "Representative")
            {
                return RedirectToPage("/Error/Unauthorized");
            }

            var representatives = new List<Representative>
            {
                new Representative { RepID = 1, RepFirstName = "John", RepLastName = "Doe", Contact = "john.doe@example.com", OrgType = "Org1", RepStatus = "Active" },
                new Representative { RepID = 2, RepFirstName = "Jane", RepLastName = "Smith", Contact = "jane.smith@example.com", OrgType = "Org2", RepStatus = "Active" }
            };

            var grants = new List<Grants>
            {
                new Grants { GrantID = 1, RepID = 1, GrantTitle = "Research Grant", Category = "Science", FundingOrg = "Funding Org 1", AwardAmount = 10000, GrantStatus = "Approved" },
                new Grants { GrantID = 2, RepID = 2, GrantTitle = "Innovation Grant", Category = "Tech", FundingOrg = "Funding Org 2", AwardAmount = 15000, GrantStatus = "Pending" }
            };

            var projects = new List<ProjectGrant>
            {
                new ProjectGrant { ProjectID = 1, RepID = 1, ProjectTitle = "Project Alpha", DueDate = DateTime.Now.AddDays(30), ProjectStatus = "In Progress", AdminID = 1 },
                new ProjectGrant { ProjectID = 2, RepID = 1, ProjectTitle = "Project Beta", DueDate = DateTime.Now.AddDays(60), ProjectStatus = "Planned", AdminID = 1 },
                new ProjectGrant { ProjectID = 3, RepID = 2, ProjectTitle = "Project Gamma", DueDate = DateTime.Now.AddDays(45), ProjectStatus = "In Progress", AdminID = 2 }
            };

            RepresentativeList = representatives.Select(r => new RepresentativeData
            {
                Rep = r,
                Grants = grants.Where(g => g.RepID == r.RepID).ToList(),
                Projects = projects.Where(p => p.RepID == r.RepID).ToList()
            }).ToList();

            return Page();
        }

        public class RepresentativeData
        {
            public Representative Rep { get; set; }
            public List<Grants> Grants { get; set; } = new List<Grants>();
            public List<ProjectGrant> Projects { get; set; } = new List<ProjectGrant>();
        }
    }
}
