using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CareSystem.Pages.Landing
{
    public class FacultyLandingModel : PageModel
    {
        public List<FacultyData> FacultyList { get; set; }

        public IActionResult OnGet()
        {
            // Only allow Faculty and Representative users.
            string role = HttpContext.Session.GetString("UserType");
            if (role != "Faculty" && role != "Representative")
            {
                return RedirectToPage("/Error/Unauthorized");
            }

            var faculties = new List<Faculty>
            {
                new Faculty { FacultyID = 1, FacultyFirstName = "Alice", FacultyLastName = "Johnson", FacultyTitle = "Professor" },
                new Faculty { FacultyID = 2, FacultyFirstName = "Bob", FacultyLastName = "Smith", FacultyTitle = "Associate Professor" }
            };

            var grants = new List<Grants>
            {
                new Grants { GrantID = 1, GrantTitle = "Science Research Grant", AwardAmount = 12000, GrantStatus = "Approved" },
                new Grants { GrantID = 2, GrantTitle = "Tech Innovation Grant", AwardAmount = 15000, GrantStatus = "Pending" },
                new Grants { GrantID = 3, GrantTitle = "Arts Development Grant", AwardAmount = 8000, GrantStatus = "Approved" }
            };

            var grantFaculties = new List<GrantFaculty>
            {
                new GrantFaculty { GrantID = 1, FacultyID = 1 },
                new GrantFaculty { GrantID = 2, FacultyID = 1 },
                new GrantFaculty { GrantID = 3, FacultyID = 2 }
            };

            FacultyList = faculties.Select(f => new FacultyData
            {
                Faculty = f,
                Grants = grantFaculties.Where(gf => gf.FacultyID == f.FacultyID)
                                        .Join(grants,
                                              gf => gf.GrantID,
                                              g => g.GrantID,
                                              (gf, g) => g)
                                        .ToList()
            }).ToList();

            return Page();
        }

        public class FacultyData
        {
            public Faculty Faculty { get; set; }
            public List<Grants> Grants { get; set; } = new List<Grants>();
        }
    }
}
