using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CareSystem.Pages.Landing
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public string Username { get; set; }
        [BindProperty]
        public string Password { get; set; }
        public string Message { get; set; }

        public void OnGet()
        {
            // Optionally, initialize Message or other properties here.
        }

        // Technique 2: OnPost() using an anonymous object
        public IActionResult OnPost()
        {
            // For demonstration, redirect using a fixed userid.
            return RedirectToPage("/Landing/UserLanding", new { userid = 316 });
        }

        // Technique 3: Custom OnPost handler that validates credentials
        public IActionResult OnPostLoginHandler()
        {
            if (Username == "Dr.Ezell" && Password == "123")
            {
                return RedirectToPage("UserLanding", new
                {
                    username = Username,
                    loginsuccess = true
                });
            }
            Message = "Login Unsuccessful!";
            return Page();
        }
    }
}
