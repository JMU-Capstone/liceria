using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CareSystem.Pages.Landing
{
    public class NonFacultyModel : PageModel
    {
        public IActionResult OnGet()
        {
            string role = HttpContext.Session.GetString("UserType");
            if (role != "NonFaculty" && role != "Representative")
            {
                return RedirectToPage("/Error/Unauthorized");
            }
            return Page();
        }
    }
}
