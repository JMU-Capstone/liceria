using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.SqlClient;

namespace CareSystem.Pages.Create
{
    public class InsertNonFacultyModel : PageModel
    {
        [BindProperty]
        public NonFaculty NonFaculty { get; set; }

        public List<SelectListItem> UsersList { get; set; } = new List<SelectListItem>();

        public void OnGet()
        {
            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID, UserName FROM Users";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    UsersList.Add(new SelectListItem
                    {
                        Value = reader["UserID"].ToString(),
                        Text = reader["UserName"].ToString()
                    });
                }
            }
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                OnGet();
                return Page();
            }

            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    INSERT INTO NonFaculty 
                        (NonFacultyID, FirstName, LastName, Department, NonFacultyTitle) 
                    VALUES 
                        (@NonFacultyID, @FirstName, @LastName, @Department, @NonFacultyTitle)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@NonFacultyID", NonFaculty.NonFacultyID);
                    cmd.Parameters.AddWithValue("@FirstName", NonFaculty.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", NonFaculty.LastName);
                    cmd.Parameters.AddWithValue("@Department", NonFaculty.Department);
                    cmd.Parameters.AddWithValue("@NonFacultyTitle", NonFaculty.NonFacultyTitle);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToPage("/Landing/DBLogin");
        }
    }
}
