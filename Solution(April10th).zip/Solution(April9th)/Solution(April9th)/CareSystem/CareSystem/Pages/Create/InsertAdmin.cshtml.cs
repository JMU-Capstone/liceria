using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.SqlClient;

namespace CareSystem.Pages.Create
{
    public class InsertAdminModel : PageModel
    {
        [BindProperty]
        public GrantOrgAdmin GrantOrgAdmin { get; set; }

        public List<SelectListItem> UsersList { get; set; } = new List<SelectListItem>();

        public void OnGet()
        {
            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID, UserName FROM Users";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    UsersList.Add(new SelectListItem
                    {
                        Value = reader["UserID"].ToString(),
                        Text = reader["UserName"].ToString()
                    });
                }
            }
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                OnGet();
                return Page();
            }

            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    INSERT INTO GrantOrgAdmin 
                    (AdminID, AdminFirstName, AdminLastName, AdminTitle)
                    VALUES 
                    (@AdminID, @AdminFirstName, @AdminLastName, @AdminTitle)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AdminID", GrantOrgAdmin.AdminID);
                    cmd.Parameters.AddWithValue("@AdminFirstName", GrantOrgAdmin.AdminFirstName);
                    cmd.Parameters.AddWithValue("@AdminLastName", GrantOrgAdmin.AdminLastName);
                    cmd.Parameters.AddWithValue("@AdminTitle", GrantOrgAdmin.AdminTitle);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToPage("/Landing/DBLogin");
        }
    }
}