using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace CareSystem.Pages.Create
{
    public class InsertRepModel : PageModel
    {
        [BindProperty]
        public Representative Representative { get; set; }

        public List<SelectListItem> UsersList { get; set; } = new List<SelectListItem>();

        public void OnGet()
        {
            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID, UserName FROM Users";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    UsersList.Add(new SelectListItem
                    {
                        Value = reader["UserID"].ToString(),
                        Text = reader["UserName"].ToString()
                    });
                }
            }
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                OnGet();
                return Page();
            }

            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    INSERT INTO Representatives 
                    (RepresentativeID, RepFirstName, RepLastName, RepStatus, Contact, OrgType)
                    VALUES 
                    (@RepresentativeID, @RepFirstName, @RepLastName, @RepStatus, @Contact, @OrgType)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@RepresentativeID", Representative.RepID);
                    cmd.Parameters.AddWithValue("@RepFirstName", Representative.RepFirstName);
                    cmd.Parameters.AddWithValue("@RepLastName", Representative.RepLastName);
                    cmd.Parameters.AddWithValue("@RepStatus", Representative.RepStatus);
                    cmd.Parameters.AddWithValue("@Contact", Representative.Contact);
                    cmd.Parameters.AddWithValue("@OrgType", Representative.OrgType);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToPage("/Landing/DBLogin");
        }
    }
}
