using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace CareSystem.Pages.Create
{
    public class InsertFacultyModel : PageModel
    {
        [BindProperty]
        public Faculty Faculty { get; set; }

        public List<SelectListItem> UsersList { get; set; } = new List<SelectListItem>();

        public void OnGet()
        {
            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID, UserName FROM Users";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    UsersList.Add(new SelectListItem
                    {
                        Value = reader["UserID"].ToString(),
                        Text = reader["UserName"].ToString()
                    });
                }
            }
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                OnGet();
                return Page();
            }

            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    INSERT INTO Faculty 
                        (FacultyID, FacultyFirstName, FacultyLastName, FacultyTitle) 
                    VALUES 
                        (@FacultyID, @FacultyFirstName, @FacultyLastName, @FacultyTitle)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@FacultyID", Faculty.FacultyID);
                    cmd.Parameters.AddWithValue("@FacultyFirstName", Faculty.FacultyFirstName);
                    cmd.Parameters.AddWithValue("@FacultyLastName", Faculty.FacultyLastName);
                    cmd.Parameters.AddWithValue("@FacultyTitle", Faculty.FacultyTitle);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToPage("/Landing/DBLogin");
        }
    }
}
