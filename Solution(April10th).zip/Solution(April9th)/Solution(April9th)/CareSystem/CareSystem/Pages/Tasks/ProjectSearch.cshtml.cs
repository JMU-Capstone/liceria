using CareSystem.Pages.Model;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace CareSystem.Pages.Tasks
{
    public class ProjectSearchModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public int? ProjectID { get; set; }
        [BindProperty(SupportsGet = true)]
        public int? AdminID { get; set; }
        [BindProperty(SupportsGet = true)]
        public int? RepID { get; set; }
        [BindProperty(SupportsGet = true)]
        public string ProjectTitle { get; set; }
        [BindProperty(SupportsGet = true)]
        public DateTime? DueDate { get; set; }
        [BindProperty(SupportsGet = true)]
        public string ProjectStatus { get; set; }

        public List<ProjectGrant> SearchResults { get; set; } = new List<ProjectGrant>();

        public void OnGet()
        {
            SearchResults = GetProjectGrants();
        }

        private List<ProjectGrant> GetProjectGrants()
        {
            List<ProjectGrant> results = new List<ProjectGrant>();
            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SearchProjectGrant", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@ProjectID", ProjectID.HasValue ? (object)ProjectID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@AdminID", AdminID.HasValue ? (object)AdminID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@RepID", RepID.HasValue ? (object)RepID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@ProjectTitle", string.IsNullOrEmpty(ProjectTitle) ? DBNull.Value : (object)ProjectTitle);
                    cmd.Parameters.AddWithValue("@DueDate", DueDate.HasValue ? (object)DueDate.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@ProjectStatus", string.IsNullOrEmpty(ProjectStatus) ? DBNull.Value : (object)ProjectStatus);

                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ProjectGrant project = new ProjectGrant
                            {
                                ProjectID = (int)reader["ProjectID"],
                                AdminID = (int)reader["AdminID"],
                                RepID = reader["RepID"] != DBNull.Value ? (int)reader["RepID"] : 0,
                                ProjectTitle = reader["ProjectTitle"].ToString(),
                                DueDate = Convert.ToDateTime(reader["DueDate"]),
                                ProjectStatus = reader["ProjectStatus"].ToString()
                            };
                            results.Add(project);
                        }
                    }
                }
            }
            return results;
        }
    }
}
