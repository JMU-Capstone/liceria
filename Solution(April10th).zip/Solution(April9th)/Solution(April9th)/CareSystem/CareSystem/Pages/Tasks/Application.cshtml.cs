using CareSystem.Pages.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.SqlClient;


namespace CareSystem.Pages.Tasks
{
    public class ApplicationModel : PageModel
    {
        [BindProperty]
        public int GrantID { get; set; }
        [BindProperty]
        public int FacultyID { get; set; }

        public List<SelectListItem> GrantsList { get; set; }
        public List<SelectListItem> FacultyList { get; set; }

        public void OnGet()
        {
            SqlDataReader grantReader = DBClass.GeneralGrantQuery("SELECT * FROM Grants");
            GrantsList = new List<SelectListItem>();
            while (grantReader.Read())
            {
                GrantsList.Add(new SelectListItem
                {
                    Value = grantReader["GrantID"].ToString(),
                    Text = grantReader["GrantTitle"].ToString()
                });
            }

            SqlDataReader facultyReader = DBClass.GeneralGrantQuery("SELECT * FROM Faculty");
            FacultyList = new List<SelectListItem>();
            while (facultyReader.Read())
            {
                FacultyList.Add(new SelectListItem
                {
                    Value = facultyReader["FacultyID"].ToString(),
                    Text = facultyReader["FacultyFirstName"].ToString()
                });
            }
        }

        public IActionResult OnPostAssignFacultyToGrant()
        {
            string sqlQuery = "INSERT INTO GrantFaculty (GrantID, FacultyID) VALUES (@GrantID, @FacultyID)";
            SqlParameter[] parameters = new SqlParameter[]
            {
        new SqlParameter("@GrantID", GrantID),
        new SqlParameter("@FacultyID", FacultyID)
            };

            DBClass.InsertGrantQuery(sqlQuery, parameters);

            return RedirectToPage("/Tasks/Home");
        }

    }
}
