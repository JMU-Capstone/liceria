using CareSystem.Page;
using CareSystem.Pages.Data;
using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace CareSystem.Pages.Tasks
{
    public class MessagesModel : SecurePageModel
    {
        public int LoggedInUserId { get; set; } = 1;

        [BindProperty]
        public int RecipientId { get; set; }
        [BindProperty]
        public string Subject { get; set; }
        [BindProperty]
        public string Body { get; set; }

        public List<Users> AllUsers { get; set; } = new List<Users>();

        public List<Message> ReceivedMessages { get; set; } = new List<Message>();

        public void OnGet()
        {
            using (SqlDataReader reader = DBClass.GetMessagesForUser(LoggedInUserId))
            {
                while (reader.Read())
                {
                    var senderName = reader["SenderName"]?.ToString() ?? "Unknown";
                    var message = new Message
                    {
                        MessageID = (int)reader["MessageID"],
                        Subject = reader["Subject"]?.ToString() ?? string.Empty,
                        Body = reader["Body"]?.ToString() ?? string.Empty,
                        SenderID = (int)reader["SenderID"],
                        ReceiverID = LoggedInUserId,
                        Sender = new Users
                        {
                            UserName = senderName,
                            Email = string.Empty,
                            Password = string.Empty,
                            Contact = string.Empty,
                            UserAddress = string.Empty,
                            City = string.Empty,
                            UserState = string.Empty,
                            UserType = string.Empty,
                            CreatedAt = DateTime.MinValue
                        }
                    };
                    ReceivedMessages.Add(message);
                }
                reader.Close();
                DBClass.CareSystemDBConnection.Close();
            }

            using (SqlDataReader userReader = DBClass.GetAllUsers())
            {
                while (userReader.Read())
                {
                    var fullName = userReader["FullName"]?.ToString() ?? string.Empty;
                    var user = new Users
                    {
                        UserID = (int)userReader["UserID"],
                        UserName = fullName
                    };
                    AllUsers.Add(user);
                }
                userReader.Close();
                DBClass.CareSystemDBConnection.Close();
            }
        }

        public IActionResult OnPostSend()
        {
            DBClass.SendMessage(LoggedInUserId, RecipientId, Subject, Body);
            return RedirectToPage();
        }
    }
}
