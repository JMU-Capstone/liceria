using CareSystem.Page;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;


namespace CareSystem.Pages.Tasks
{
    public class HomeModel : SecurePageModel
    {
        public void OnGet()
        {
        }
    }
}
