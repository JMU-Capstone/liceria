using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CareSystem.Pages.Tasks
{
    public class CalenderModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
