using CareSystem.Pages.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;


namespace CareSystem.Pages.Tasks
{
    public class CalenderEventsModel : PageModel
    {
        public IActionResult OnGet()
        {
            var events = new List<object>();

            // Query for grant events. These are based on AwardDate in the Grants table.
            string grantQuery = "SELECT GrantTitle, AwardDate FROM Grants WHERE AwardDate IS NOT NULL";
            using (SqlDataReader reader = DBClass.GeneralGrantQuery(grantQuery))
            {
                while (reader.Read())
                {
                    DateTime awardDate = (DateTime)reader["AwardDate"];
                    events.Add(new
                    {
                        title = reader["GrantTitle"].ToString(),
                        start = awardDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                        source = "grant"
                    });
                }
                reader.Close();
            }

            // Query for project events. These are based on DueDate in the ProjectGrant table.
            string projectQuery = "SELECT ProjectTitle, DueDate FROM ProjectGrant WHERE DueDate IS NOT NULL";
            using (SqlDataReader reader = DBClass.GeneralProjectQuery(projectQuery))
            {
                while (reader.Read())
                {
                    DateTime dueDate = (DateTime)reader["DueDate"];
                    events.Add(new
                    {
                        title = reader["ProjectTitle"].ToString(),
                        start = dueDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                        source = "project"
                    });
                }
                reader.Close();
            }

            return new JsonResult(events);
        }
    }
}
