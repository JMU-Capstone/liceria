using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;


namespace CareSystem.Pages.Tasks
{
    public class ProjectWorkflowModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
