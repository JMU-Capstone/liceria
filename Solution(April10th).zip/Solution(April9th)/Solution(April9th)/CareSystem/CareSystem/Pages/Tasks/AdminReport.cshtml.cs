using CareSystem.Page;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;


namespace CareSystem.Pages.Tasks
{
    public class AdminReportModel : PageModel
    {
        [BindProperty]
        public string ReportType { get; set; }
        [BindProperty]
        public DateTime? StartDate { get; set; }
        [BindProperty]
        public DateTime? EndDate { get; set; }
        [BindProperty]
        public string StatusFilter { get; set; }
        [BindProperty]
        public string TypeFilter { get; set; }
        [BindProperty]
        public string SearchText { get; set; }

        // DataTable to hold the report results.
        public DataTable ReportResults { get; set; }

        public void OnGet()
        {
            // Optionally, initialize defaults.
        }

        public IActionResult OnPost()
        {
            string query = "";
            List<SqlParameter> parameters = new List<SqlParameter>();

            // Build query based on report type.
            if (ReportType == "Grants")
            {
                query = "SELECT * FROM Grants WHERE 1=1";
                if (StartDate.HasValue)
                {
                    query += " AND SubmitDate >= @StartDate";
                    parameters.Add(new SqlParameter("@StartDate", StartDate.Value));
                }
                if (EndDate.HasValue)
                {
                    query += " AND SubmitDate <= @EndDate";
                    parameters.Add(new SqlParameter("@EndDate", EndDate.Value));
                }
                if (!string.IsNullOrEmpty(StatusFilter))
                {
                    query += " AND GrantStatus = @StatusFilter";
                    parameters.Add(new SqlParameter("@StatusFilter", StatusFilter));
                }
                if (!string.IsNullOrEmpty(TypeFilter))
                {
                    query += " AND Category LIKE @TypeFilter";
                    parameters.Add(new SqlParameter("@TypeFilter", "%" + TypeFilter + "%"));
                }
                if (!string.IsNullOrEmpty(SearchText))
                {
                    query += " AND (GrantTitle LIKE @SearchText OR FundingOrg LIKE @SearchText)";
                    parameters.Add(new SqlParameter("@SearchText", "%" + SearchText + "%"));
                }
            }
            else if (ReportType == "Projects")
            {
                query = "SELECT * FROM ProjectGrant WHERE 1=1";
                if (StartDate.HasValue)
                {
                    query += " AND DueDate >= @StartDate";
                    parameters.Add(new SqlParameter("@StartDate", StartDate.Value));
                }
                if (EndDate.HasValue)
                {
                    query += " AND DueDate <= @EndDate";
                    parameters.Add(new SqlParameter("@EndDate", EndDate.Value));
                }
                if (!string.IsNullOrEmpty(StatusFilter))
                {
                    query += " AND ProjectStatus = @StatusFilter";
                    parameters.Add(new SqlParameter("@StatusFilter", StatusFilter));
                }
                if (!string.IsNullOrEmpty(TypeFilter))
                {
                    query += " AND ProjectTitle LIKE @TypeFilter";
                    parameters.Add(new SqlParameter("@TypeFilter", "%" + TypeFilter + "%"));
                }
                if (!string.IsNullOrEmpty(SearchText))
                {
                    query += " AND (ProjectTitle LIKE @SearchText)";
                    parameters.Add(new SqlParameter("@SearchText", "%" + SearchText + "%"));
                }
            }
            else if (ReportType == "Faculty")
            {
                query = "SELECT * FROM Faculty WHERE 1=1";
                if (!string.IsNullOrEmpty(SearchText))
                {
                    query += " AND (FacultyFirstName LIKE @SearchText OR FacultyLastName LIKE @SearchText)";
                    parameters.Add(new SqlParameter("@SearchText", "%" + SearchText + "%"));
                }
            }
            else if (ReportType == "Partners")
            {
                // For Business Partners and their Reps, we join PotentialPartner, GrantOrgAdmin, and Representative.
                query = @"
SELECT pp.*, 
       goa.AdminFirstName, goa.AdminLastName, 
       rep.RepFirstName, rep.RepLastName, rep.RepStatus, rep.Contact, rep.OrgType
FROM PotentialPartner pp
INNER JOIN GrantOrgAdmin goa ON pp.AdminID = goa.AdminID
INNER JOIN Representative rep ON pp.RepID = rep.RepID
WHERE 1=1";
                if (!string.IsNullOrEmpty(SearchText))
                {
                    query += " AND (OrgTitle LIKE @SearchText OR rep.RepFirstName LIKE @SearchText OR rep.RepLastName LIKE @SearchText)";
                    parameters.Add(new SqlParameter("@SearchText", "%" + SearchText + "%"));
                }
            }

            // Execute the query and load results into a DataTable.
            ReportResults = new DataTable();
            string connStr = "Server=Localhost;Database=CareSystem ;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddRange(parameters.ToArray());
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ReportResults.Load(reader);
                }
            }
            return Page();
        }
    }
}
