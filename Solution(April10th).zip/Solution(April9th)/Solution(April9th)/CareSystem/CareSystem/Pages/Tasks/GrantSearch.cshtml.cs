using CareSystem.Pages.Model;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace CareSystem.Pages.Tasks
{
    public class GrantSearchModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public int? RepID { get; set; }
        [BindProperty(SupportsGet = true)]
        public string GrantTitle { get; set; }
        [BindProperty(SupportsGet = true)]
        public string Category { get; set; }
        [BindProperty(SupportsGet = true)]
        public string FundingOrg { get; set; }
        [BindProperty(SupportsGet = true)]
        public DateTime? SubmitDate { get; set; }
        [BindProperty(SupportsGet = true)]
        public DateTime? AwardDate { get; set; }
        [BindProperty(SupportsGet = true)]
        public decimal? AwardAmount { get; set; }
        [BindProperty(SupportsGet = true)]
        public string ProjectLead { get; set; }
        [BindProperty(SupportsGet = true)]
        public string GrantStatus { get; set; }

        public List<Grants> SearchResults { get; set; } = new List<Grants>();

        public void OnGet()
        {
            SearchResults = GetGrants();
        }

        private List<Grants> GetGrants()
        {
            List<Grants> results = new List<Grants>();

            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SearchGrants", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@RepID", RepID.HasValue ? (object)RepID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@GrantTitle", string.IsNullOrEmpty(GrantTitle) ? DBNull.Value : (object)GrantTitle);
                    cmd.Parameters.AddWithValue("@Category", string.IsNullOrEmpty(Category) ? DBNull.Value : (object)Category);
                    cmd.Parameters.AddWithValue("@FundingOrg", string.IsNullOrEmpty(FundingOrg) ? DBNull.Value : (object)FundingOrg);
                    cmd.Parameters.AddWithValue("@SubmitDate", SubmitDate.HasValue ? (object)SubmitDate.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@AwardDate", AwardDate.HasValue ? (object)AwardDate.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@AwardAmount", AwardAmount.HasValue ? (object)AwardAmount.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@ProjectLead", string.IsNullOrEmpty(ProjectLead) ? DBNull.Value : (object)ProjectLead);
                    cmd.Parameters.AddWithValue("@GrantStatus", string.IsNullOrEmpty(GrantStatus) ? DBNull.Value : (object)GrantStatus);

                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Grants grant = new Grants
                            {
                                GrantID = (int)reader["GrantID"],
                                RepID = reader["RepID"] != DBNull.Value ? (int?)reader["RepID"] : null,
                                GrantTitle = reader["GrantTitle"].ToString(),
                                Category = reader["Category"].ToString(),
                                FundingOrg = reader["FundingOrg"].ToString(),
                                SubmitDate = Convert.ToDateTime(reader["SubmitDate"]),
                                AwardDate = reader["AwardDate"] != DBNull.Value ? (DateTime?)reader["AwardDate"] : null,
                                AwardAmount = (decimal)reader["AwardAmount"],
                                ProjectLead = reader["ProjectLead"].ToString(),
                                GrantStatus = reader["GrantStatus"].ToString()
                            };
                            results.Add(grant);
                        }
                    }
                }
            }
            return results;
        }
    }
}
