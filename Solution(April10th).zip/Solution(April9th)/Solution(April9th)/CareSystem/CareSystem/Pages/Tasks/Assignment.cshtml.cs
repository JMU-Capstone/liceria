using CareSystem.Pages.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.SqlClient;

namespace CareSystem.Pages.Tasks
{
    public class AssignmentModel : PageModel
    {
        [BindProperty]
        public int ProjectID { get; set; }
        [BindProperty]
        public int AdminID { get; set; }

        public List<SelectListItem> ProjectList { get; set; }
        public List<SelectListItem> AdminList { get; set; }

        public void OnGet()
        {
            SqlDataReader projectReader = DBClass.GeneralGrantQuery("SELECT * FROM ProjectGrant");
            ProjectList = new List<SelectListItem>();
            while (projectReader.Read())
            {
                ProjectList.Add(new SelectListItem
                {
                    Value = projectReader["ProjectID"].ToString(),
                    Text = projectReader["ProjectTitle"].ToString()
                });
            }

            SqlDataReader adminReader = DBClass.GeneralGrantQuery("SELECT * FROM GrantOrgAdmin");
            AdminList = new List<SelectListItem>();
            while (adminReader.Read())
            {
                ProjectList.Add(new SelectListItem
                {
                    Value = adminReader["AdminID"].ToString(),
                    Text = adminReader["AdminFirstName"].ToString()
                });
            }
        }

    }
}
