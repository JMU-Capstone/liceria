using CareSystem.Pages.Data;
using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;


namespace CareSystem.Pages.Tasks
{
    public class RegistrationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
          
