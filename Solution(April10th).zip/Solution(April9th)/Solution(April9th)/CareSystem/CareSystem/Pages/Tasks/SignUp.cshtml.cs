using CareSystem.Pages.Data;
using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.SqlClient;


namespace CareSystem.Pages.Tasks
{
    public class SignUpModel : PageModel
    {
        [BindProperty]
        public string UserName { get; set; }

        [BindProperty]
        public string Password { get; set; }

        [BindProperty]
        public string Contact { get; set; }

        [BindProperty]
        public string Email { get; set; }

        [BindProperty]
        public string UserAddress { get; set; }

        [BindProperty]
        public string City { get; set; }

        [BindProperty]
        public string UserState { get; set; }

        [BindProperty]
        public string UserType { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            DateTime createdAt = DateTime.Now;
            int userId;

            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    INSERT INTO Users 
                    (UserName, Password, Contact, Email, UserAddress, City, UserState, UserType, CreatedAt) 
                    VALUES 
                    (@UserName, @Password, @Contact, @Email, @UserAddress, @City, @UserState, @UserType, @CreatedAt);
                    SELECT SCOPE_IDENTITY();";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Parameterized queries to prevent SQL injection:
                    cmd.Parameters.AddWithValue("@UserName", UserName);
                    cmd.Parameters.AddWithValue("@Password", Password);
                    cmd.Parameters.AddWithValue("@Contact", Contact);
                    cmd.Parameters.AddWithValue("@Email", Email);
                    cmd.Parameters.AddWithValue("@UserAddress", UserAddress);
                    cmd.Parameters.AddWithValue("@City", City);
                    cmd.Parameters.AddWithValue("@UserState", UserState);
                    cmd.Parameters.AddWithValue("@UserType", UserType);
                    cmd.Parameters.AddWithValue("@CreatedAt", createdAt);

                    conn.Open();
                    userId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }

            switch (UserType)
            {
                case "Faculty":
                    return RedirectToPage("/Create/InsertFaculty");
                case "NonFaculty":
                    return RedirectToPage("/Create/InsertNonFaculty");
                case "GrantOrgAdmin":
                    return RedirectToPage("/Create/InsertAdmin", new { userId = userId });
                case "Representative":
                    return RedirectToPage("/Create/InsertRep");
                default:
                    return RedirectToPage("/Create/InsertFaculty");
            }
        }
    }
}