using CareSystem.Pages.Model;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace CareSystem.Pages.Tasks
{
    public class UserSearchModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public int? UserID { get; set; }
        [BindProperty(SupportsGet = true)]
        public string Username { get; set; }
        [BindProperty(SupportsGet = true)]
        public string Contact { get; set; }
        [BindProperty(SupportsGet = true)]
        public string Email { get; set; }
        [BindProperty(SupportsGet = true)]
        public string UserAddress { get; set; }
        [BindProperty(SupportsGet = true)]
        public string City { get; set; }
        [BindProperty(SupportsGet = true)]
        public string UserState { get; set; }
        [BindProperty(SupportsGet = true)]
        public string UserType { get; set; }
        [BindProperty(SupportsGet = true)]
        public DateTime? CreatedAt { get; set; }

        public List<Users> SearchResults { get; set; } = new List<Users>();

        public void OnGet()
        {
            SearchResults = GetUsers();
        }

        private List<Users> GetUsers()
        {
            List<Users> results = new List<Users>();
            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SearchUsers", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@UserID", UserID.HasValue ? (object)UserID.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@Username", string.IsNullOrEmpty(Username) ? DBNull.Value : (object)Username);
                    cmd.Parameters.AddWithValue("@Contact", string.IsNullOrEmpty(Contact) ? DBNull.Value : (object)Contact);
                    cmd.Parameters.AddWithValue("@Email", string.IsNullOrEmpty(Email) ? DBNull.Value : (object)Email);
                    cmd.Parameters.AddWithValue("@UserAddress", string.IsNullOrEmpty(UserAddress) ? DBNull.Value : (object)UserAddress);
                    cmd.Parameters.AddWithValue("@City", string.IsNullOrEmpty(City) ? DBNull.Value : (object)City);
                    cmd.Parameters.AddWithValue("@UserState", string.IsNullOrEmpty(UserState) ? DBNull.Value : (object)UserState);
                    cmd.Parameters.AddWithValue("@UserType", string.IsNullOrEmpty(UserType) ? DBNull.Value : (object)UserType);
                    cmd.Parameters.AddWithValue("@CreatedAt", CreatedAt.HasValue ? (object)CreatedAt.Value : DBNull.Value);

                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Users user = new Users
                            {
                                UserID = (int)reader["UserID"],
                                UserName = reader["Username"].ToString(),
                                Contact = reader["Contact"].ToString(),
                                Email = reader["Email"].ToString(),
                                UserAddress = reader["UserAddress"].ToString(),
                                City = reader["City"].ToString(),
                                UserState = reader["UserState"].ToString(),
                                UserType = reader["UserType"].ToString(),
                                CreatedAt = Convert.ToDateTime(reader["CreatedAt"])
                            };
                            results.Add(user);
                        }
                    }
                }
            }
            return results;
        }
    }
}
