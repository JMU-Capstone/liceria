using CareSystem.Page;
using CareSystem.Pages.Data;
using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.SqlClient;

namespace CareSystem.Pages.Workflow
{
    public class GrantModel : SecurePageModel
    {
        [BindProperty]
        public Grants NewGrants { get; set; }

        public IEnumerable<SelectListItem> FacultyList { get; set; }

        public void OnGet()
        {
            NewGrants = new Grants();

            var faculty = DBClass.GetAllFaculty();
            FacultyList = faculty.Select(f => new SelectListItem
            {
                Value = f.FacultyID.ToString(),
                Text = $"{f.FacultyFirstName} {f.FacultyLastName}"
            });
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                var faculty = DBClass.GetAllFaculty();
                FacultyList = faculty.Select(f => new SelectListItem
                {
                    Value = f.FacultyID.ToString(),
                    Text = $"{f.FacultyFirstName} {f.FacultyLastName}"
                });
                return Page();
            }

            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    INSERT INTO Grants 
                    (RepID, Category, FundingOrg, AwardDate, AwardAmount)
                    VALUES 
                    (@RepID, @Category, @FundingOrg, @AwardDate, @AwardAmount);
                    SELECT SCOPE_IDENTITY();";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@RepID", NewGrants.RepID);
                    cmd.Parameters.AddWithValue("@Category", NewGrants.Category);
                    cmd.Parameters.AddWithValue("@FundingOrg", NewGrants.FundingOrg);
                    cmd.Parameters.AddWithValue("@AwardDate", NewGrants.AwardDate);
                    cmd.Parameters.AddWithValue("@AwardAmount", NewGrants.AwardAmount);

                    conn.Open();
                    object result = cmd.ExecuteScalar();
                    if (result != null && int.TryParse(result.ToString(), out int newId))
                    {
                        NewGrants.GrantID = newId;
                    }
                }
            }

            return RedirectToPage("/Tasks/Home");
        }
    }
}
