using CareSystem.Pages.Data;
using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace CareSystem.Pages.Workflow
{
    public class UpdateGrantStatusModel : PageModel
    {
        [BindProperty]
        public Grants CurrentGrant { get; set; }

        [BindProperty]
        public string NewStatus { get; set; }

        // OnGet: load the grant record using the provided GrantID (from route)
        public void OnGet(int id)
        {
            SqlDataReader reader = DBClass.SingleGrantReader(id);
            if (reader.Read())
            {
                CurrentGrant = new Grants
                {
                    GrantID = (int)reader["GrantID"],
                    RepID = reader["RepID"] != DBNull.Value ? (int)reader["RepID"] : 0,
                    GrantTitle = reader["GrantTitle"].ToString(),
                    Category = reader["Category"].ToString(),
                    FundingOrg = reader["FundingOrg"].ToString(),
                    SubmitDate = reader["SubmitDate"] != DBNull.Value ? (DateTime)reader["SubmitDate"] : DateTime.MinValue,
                    AwardDate = reader["AwardDate"] != DBNull.Value ? (DateTime)reader["AwardDate"] : DateTime.MinValue,
                    AwardAmount = reader["AwardAmount"] != DBNull.Value ? (decimal)reader["AwardAmount"] : 0,
                    ProjectLead = reader["ProjectLead"].ToString(),
                    GrantStatus = reader["GrantStatus"].ToString()
                };
            }
            reader.Close();
            DBClass.CareSystemDBConnection.Close();
        }

        // OnPost: update the grant�s status in the database
        public IActionResult OnPost()
        {
            if (string.IsNullOrEmpty(NewStatus))
            {
                ModelState.AddModelError("NewStatus", "Please select a status.");
                return Page();
            }

            string sqlQuery = "UPDATE Grants SET GrantStatus = @GrantStatus WHERE GrantID = @GrantID";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@GrantStatus", NewStatus),
                new SqlParameter("@GrantID", CurrentGrant.GrantID)
            };

            DBClass.InsertGrantQuery(sqlQuery, parameters);

            return RedirectToPage("/Tasks/Home");
        }

        // Helper method to map a status string to a Bootstrap badge class
        public string GetStatusBadge(string status)
        {
            switch (status)
            {
                case "Opportunity":
                    return "bg-info";
                case "Draft":
                    return "bg-secondary";
                case "Applied":
                    return "bg-primary";
                case "Pending":
                    return "bg-warning text-dark";
                case "Awarded or Rejected":
                    return "bg-danger";
                case "Completed":
                    return "bg-success";
                default:
                    return "bg-light text-dark";
            }
        }
    }
}
