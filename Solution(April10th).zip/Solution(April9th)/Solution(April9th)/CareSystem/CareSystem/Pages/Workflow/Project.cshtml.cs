using CareSystem.Page;
using CareSystem.Pages.Data;
using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace CareSystem.Pages.Workflow
{
    public class ProjectModel : SecurePageModel
    {
        [BindProperty]
        public ProjectGrant NewProject { get; set; }

        public IEnumerable<SelectListItem> AdminList { get; set; }

        public void OnGet()
        {
            NewProject = new ProjectGrant();

            var admins = DBClass.GetAllAdmin();
            AdminList = admins.Select(a => new SelectListItem
            {
                Value = a.AdminID.ToString(),
                Text = $"{a.AdminFirstName} {a.AdminLastName}"
            });
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                var admins = DBClass.GetAllAdmin();
                AdminList = admins.Select(a => new SelectListItem
                {
                    Value = a.AdminID.ToString(),
                    Text = $"{a.AdminFirstName} {a.AdminLastName}"
                });
                return Page();
            }

            string connectionString = "Server=Localhost;Database=CareSystem;Trusted_Connection=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                    INSERT INTO ProjectGrant 
                    (AdminID, ProjectTitle, DueDate, ProjectStatus)
                    VALUES 
                    (@AdminID, @ProjectTitle, @DueDate, @ProjectStatus);
                    SELECT SCOPE_IDENTITY();";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AdminID", NewProject.AdminID);
                    cmd.Parameters.AddWithValue("@ProjectTitle", NewProject.ProjectTitle);
                    cmd.Parameters.AddWithValue("@DueDate", NewProject.DueDate);
                    cmd.Parameters.AddWithValue("@ProjectStatus", NewProject.ProjectStatus);

                    conn.Open();
                    object result = cmd.ExecuteScalar();
                    if (result != null && int.TryParse(result.ToString(), out int newId))
                    {
                        NewProject.ProjectID = newId;
                    }
                }
            }

            return RedirectToPage("/Tasks/Home");
        }
    }
}