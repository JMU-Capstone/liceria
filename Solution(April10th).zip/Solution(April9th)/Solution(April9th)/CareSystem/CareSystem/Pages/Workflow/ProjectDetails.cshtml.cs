using CareSystem.Pages.Data;
using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;


namespace CareSystem.Pages.Workflow
{
    public class ProjectDetailsModel : PageModel
    {
        [BindProperty]
        public ProjectGrant Project { get; set; }

        public string AdminName { get; set; }

        public List<Meeting> MeetingNotes { get; set; } = new List<Meeting>();

        public IActionResult OnGet(int id)
        {
            string sqlQuery = @"
                SELECT pg.*, goa.AdminFirstName, goa.AdminLastName 
                FROM ProjectGrant pg 
                INNER JOIN GrantOrgAdmin goa ON pg.AdminID = goa.AdminID 
                WHERE pg.ProjectID = @ProjectID";
            using (SqlConnection conn = new SqlConnection("Server=Localhost;Database=CareSystem;Trusted_Connection=True"))
            {
                using (SqlCommand cmd = new SqlCommand(sqlQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@ProjectID", id);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        Project = new ProjectGrant
                        {
                            ProjectID = (int)reader["ProjectID"],
                            AdminID = (int)reader["AdminID"],
                            RepID = reader["RepID"] != DBNull.Value ? (int)reader["RepID"] : 0,
                            ProjectTitle = reader["ProjectTitle"].ToString(),
                            DueDate = reader["DueDate"] != DBNull.Value ? (DateTime)reader["DueDate"] : DateTime.MinValue,
                            ProjectStatus = reader["ProjectStatus"].ToString()
                        };
                        AdminName = reader["AdminFirstName"].ToString() + " " + reader["AdminLastName"].ToString();
                    }
                    reader.Close();
                }
            }


            string meetingQuery = "SELECT * FROM Meeting WHERE RepID = @RepID AND AdminID = @AdminID";
            using (SqlConnection conn = new SqlConnection("Server=Localhost;Database=CareSystem;Trusted_Connection=True"))
            {
                using (SqlCommand cmd = new SqlCommand(meetingQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@RepID", Project.RepID);
                    cmd.Parameters.AddWithValue("@AdminID", Project.AdminID);
                    conn.Open();
                    SqlDataReader meetingReader = cmd.ExecuteReader();
                    while (meetingReader.Read())
                    {
                        Meeting meeting = new Meeting
                        {
                            MeetingID = (int)meetingReader["MeetingID"],
                            AdminID = (int)meetingReader["AdminID"],
                            RepID = (int)meetingReader["RepID"],
                            MeetingMinutes = meetingReader["MeetingMinutes"].ToString()
                        };
                        MeetingNotes.Add(meeting);
                    }
                    meetingReader.Close();
                }
            }

            return Page();
        }

        public string GetStatusBadge(string status)
        {
            switch (status)
            {
                case "Not Started":
                    return "bg-secondary";
                case "In Progress":
                    return "bg-warning text-dark";
                case "Completed":
                    return "bg-success";
                default:
                    return "bg-light text-dark";
            }
        }
    }
}
