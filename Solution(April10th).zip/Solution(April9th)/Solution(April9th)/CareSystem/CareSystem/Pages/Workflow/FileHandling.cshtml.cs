using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CareSystem.Pages.Workflow
{
    public class FileHandlingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
