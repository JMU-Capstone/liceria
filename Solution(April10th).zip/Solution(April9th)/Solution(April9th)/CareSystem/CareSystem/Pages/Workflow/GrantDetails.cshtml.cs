using CareSystem.Pages.Data;
using CareSystem.Pages.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;


namespace CareSystem.Pages.Workflow
{
    public class GrantDetailsModel : PageModel
    {
        [BindProperty]
        public Grants Grant { get; set; }

        public List<GrantNotes> Notes { get; set; } = new List<GrantNotes>();

        public IActionResult OnGet(int id)
        {
            // Retrieve the grant details
            SqlDataReader reader = DBClass.SingleGrantReader(id);
            if (reader.Read())
            {
                Grant = new Grants
                {
                    GrantID = (int)reader["GrantID"],
                    RepID = reader["RepID"] != DBNull.Value ? (int)reader["RepID"] : 0,
                    GrantTitle = reader["GrantTitle"].ToString(),
                    Category = reader["Category"].ToString(),
                    FundingOrg = reader["FundingOrg"].ToString(),
                    SubmitDate = reader["SubmitDate"] != DBNull.Value ? (DateTime)reader["SubmitDate"] : DateTime.MinValue,
                    AwardDate = reader["AwardDate"] != DBNull.Value ? (DateTime)reader["AwardDate"] : DateTime.MinValue,
                    AwardAmount = reader["AwardAmount"] != DBNull.Value ? (decimal)reader["AwardAmount"] : 0,
                    ProjectLead = reader["ProjectLead"].ToString(),
                    GrantStatus = reader["GrantStatus"].ToString()
                };
            }
            reader.Close();
            DBClass.CareSystemDBConnection.Close();

            // Retrieve associated notes for this grant
            string sqlQuery = "SELECT * FROM GrantNotes WHERE GrantID = @GrantID";
            using (SqlConnection conn = new SqlConnection("Server=Localhost;Database=CareSystem;Trusted_Connection=True"))
            {
                using (SqlCommand cmd = new SqlCommand(sqlQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@GrantID", id);
                    conn.Open();
                    SqlDataReader noteReader = cmd.ExecuteReader();
                    while (noteReader.Read())
                    {
                        GrantNotes note = new GrantNotes
                        {
                            GrantNotesID = (int)noteReader["GrantNotesID"],
                            GrantID = (int)noteReader["GrantID"],
                            GrantContent = noteReader["GrantContent"].ToString()
                        };
                        Notes.Add(note);
                    }
                    noteReader.Close();
                }
            }

            return Page();
        }

        public string GetStatusBadge(string status)
        {
            switch (status)
            {
                case "Opportunity":
                    return "bg-info";
                case "Draft":
                    return "bg-secondary";
                case "Applied":
                    return "bg-primary";
                case "Pending":
                    return "bg-warning text-dark";
                case "Awarded or Rejected":
                    return "bg-danger";
                case "Completed":
                    return "bg-success";
                default:
                    return "bg-light text-dark";
            }
        }
    }
}

